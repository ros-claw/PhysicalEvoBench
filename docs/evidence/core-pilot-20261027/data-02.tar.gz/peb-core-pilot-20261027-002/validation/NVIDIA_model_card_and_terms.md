---
tags:
- robotics
---

<div align="center">
  <a href="https://github.com/isaac-sim/IsaacLab-Arena">
    <img src="https://img.shields.io/badge/GitHub-grey?logo=GitHub" alt="GitHub Badge">
  </a>
  <a href="https://fictional-disco-qm1zq12.pages.github.io/html/index.html">
    <img src="https://img.shields.io/badge/Website-green" alt="Website Badge">
  </a>
</div>

## Description:

Arena-Franka-Lift-Object-RL-Task is a model trained for the object lifting task in one of IsaacLab-Arena example workflows. The Franka Panda robot learns to grasp and lift objects (cube-shaped primitives on a table) to target positions through reinforcement learning. The task uses a command-based goal specification, where the RL agent learns to reach sampled target poses.<br><br>
This model is ready for non-commercial use only.

## Governing Terms
Your usage of the Arena-Franka-Lift-Object-RL-Task is governed by the [NVIDIA License](https://developer.download.nvidia.com/licenses/NVIDIA-OneWay-Noncommercial-License-22Mar2022.pdf?t=eyJscyI6ImdzZW8iLCJsc2QiOiJodHRwczovL3d3dy5nb29nbGUuY29tLyIsIm5jaWQiOiJzby15b3V0LTg3MTcwMS12dDQ4In0=).

### Deployment Geography:
Global

### Release Date:

GitHub: 04/09/2026 via [isaac-sim/IsaacLab-Arena](https://github.com/isaac-sim/IsaacLab-Arena/)
Hugging Face: 04/09/2026 via [nvidia/Arena-Franka-Lift-Object-RL-Task](https://huggingface.co/nvidia/Arena-Franka-Lift-Object-RL-Task)

### Use Case:
Researchers, Academics, Open-Source Community: AI-driven robotics research and algorithm development.
Developers: Integrate and customize AI for various robotic applications.
Startups & Companies: Accelerate robotics development and reduce training costs.

## Reference(s):
[RSL‑RL: A Learning Library for Robotics Research, arXiv preprint (2025)](https://arxiv.org/abs/2509.10771)

## Model Architecture:

**Architecture Type:**  Multi-layer Perceptron

**Network Architecture:** 
MLP network trained with on-policy PPO using RSL-RL PPO framework.

**Number of Model Parameters:**
105,871

## Input:
**Input Type:**
* Robot State: End-effector pose capsulating position and rotation [x, y, z, w, x, y, z]<br>

**Input Format:**
* Robot State: Floating Point<br>

**Input Parameters:**
* Robot State: One-Dimensional (1D) - Floating number vector<br>

**Other Properties Related to Input:** Continuous-value vectors correspond to different motor controls on a robot, which depends on Degrees of Freedom of the robot embodiment.

## Output:
**Output Type(s):** End-effector target pose<br>
**Output Format:** Continuous-value vectors<br>
**Output Parameters:** [One-Dimensional (1D)] <br>
**Other Properties Related to Output:** Continuous-value vectors correspond to different motor controls on a robot, which depends on Degrees of Freedom of the robot embodiment.

Our AI models are designed and/or optimized to run on NVIDIA GPU-accelerated systems. By leveraging NVIDIA's hardware (e.g. GPU cores) and software frameworks (e.g., CUDA libraries), the model achieves faster training and inference times compared to CPU-only solutions. <br>

The integration of foundation and fine-tuned models into AI systems requires additional testing using use-case-specific data to ensure safe and effective deployment. Following the V-model methodology, iterative testing and validation at both unit and system levels are essential to mitigate risks, meet technical and functional requirements, and ensure compliance with safety and ethical standards before deployment.

## Model Version(s):
Version 0.1.

# Training, Testing, and Evaluation:

## Training & Testing

The model was trained completely in simulation (IsaacLab-Arena) using a on-policy Reinforcement Learning method.

**Data Modality:** Other: Robot simulation

**Training Data Size:** Not Applicable

**Data Collection Method:** Simulated Franka - Reinforcement Learning

**Labeling Method:** Not Applicable

**Properties:** The model was trained completely in simulation (IsaacLab-Arena) using a on-policy Reinforcement Learning method. In this case, the data was collected for a couple of episodes, then the algorithm ran gradient descent on the collected data to update the model weights. Once this step was completed, the collected data was discarded and a new batch of data was collected.

The simulation environment contained the robot itself, a cube sitting on a table, and a ground plane.

## Evaluation

**Data Modality:** Other: Robot simulation

**Data Collection Method:** Simulated Franka - Reinforcement Learning

**Labeling Method:** Not Applicable

**Properties:** The evaluation was performed in simulation using the IsaacLab-Arena. The evaluation data consists of dynamically generated episodes of lifting tasks.

## Inference:
**Acceleration Engine(s):** PyTorch

**Test Hardwares** 
* NVIDIA RTX 6000 Ada

## Software Integration

**Runtime Engine(s):** Not Applicable

**Supported Hardware Microarchitecture Compatibility:**
All of the below:
* NVIDIA Ampere
* NVIDIA Blackwell
* NVIDIA Jetson
* NVIDIA Hopper
* NVIDIA Lovelace

**Preferred/Supported Operating System(s):** Linux

## Ethical Considerations:
NVIDIA believes Trustworthy AI is a shared responsibility and we have established policies and practices to enable development for a wide array of AI applications.  When downloaded or used in accordance with our terms of service, developers should work with their internal model team to ensure this model meets requirements for the relevant industry and use case and addresses unforeseen product misuse.  

Please report model quality, risk, security vulnerabilities or NVIDIA AI Concerns [here](https://www.nvidia.com/en-us/support/submit-security-vulnerability/).
